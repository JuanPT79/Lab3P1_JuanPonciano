
package lab3p1_juanponciano;

import java.util.Scanner;

public class Lab3P1_JuanPonciano {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        
        System.out.println("***MENU***");
        System.out.println("Ejercicio 1: Suceciones y más Sucesiones");
        System.out.println("Ejercicio 2: Pocket Monsters");
        System.out.println("Ejercicio 3: ¡Asterísco en Casa!");
        System.out.print("Ingrese el ejercicio: ");
        int ejercicio = leer.nextInt();
        
        switch (ejercicio){
            case 1:{
                System.out.print("Diferencia: ");
                int diferencia = leer.nextInt();
                System.out.print("Inicial: ");
                int inicial = leer.nextInt();
                System.out.print("Cantidad: ");
                int cantidad = leer.nextInt();

                for(int contador = 1; contador <= cantidad; contador++){
                    System.out.print(inicial);
                    inicial = inicial + diferencia;
                    if (contador < cantidad){
                        System.out.print(",");
                                            }
                            else {
                            System.out.print(" ");
                                     }
                }
                System.out.println();
                System.out.println("¿Qué número desea ver más adelante en la sucesión?");
                int sucesión = leer.nextInt();
                System.out.println("El número dice: "+sucesión);
            
            }
            break;
            
            case 2:{
                System.out.println("Ingrese el modo de pelea pokemon que desea:");
                System.out.println("1. Hasta la muerte");
                System.out.println("2. Por rondas");
                int modo = leer.nextInt();
                
                switch(modo){
                    case 1:{
                    System.out.println("Estadísticas de los pokemons");
                    System.out.println("Sylveon Vida:280 Ataque:80 Defensa:15%");
                    System.out.println("Gyarados Vida:300 Ataque:50 Defensa:10%");
                    System.out.println("Giratina Vida:300 Ataque:75 Defensa:20%");
                    System.out.println("Dragonite Vida:250 Ataque:75 Defensa:20%");
                    System.out.println();
                    System.out.println("Ingrese una pelea determinada");
                    System.out.println("1.- Sylveon vrs Dragonite");
                    System.out.println("2.- Gyarados vrs Giratina");
                    System.out.println("3.- Dragonite vrs Giratina");
                    System.out.println("4.- Giratina vrs Sylveon"); 
                    System.out.println();
                    int pelea = leer.nextInt();
                    double sylveon = 280, dragonite =250, gyarados = 300, giratina =300;
                        switch (pelea){
                            case 1:{
                                double pokemon1 = 280;
                                double pokemon2 = 250;
                                while(pokemon1 >0 || pokemon2 >0){
                                for(int ronda = 1; ronda <= 10; ronda++){ 
                                System.out.println("-----------Ronda "+ronda+"-----------"); 
                                }
                            }
                            }
                            break;
                            
                            case 2:{
                                
                            }
                            break;
                            
                            case 3:{
                                
                            }
                            break;
                            
                            case 4:{
                                
                            }
                            break;
                        }
                    }
                    break;
                    
                    case 2:{
                    System.out.println("Estadísticas de los pokemons");
                    System.out.println("Sylveon Vida:280 Ataque:80 Defensa:15%");
                    System.out.println("Gyarados Vida:300 Ataque:50 Defensa:10%");
                    System.out.println("Giratina Vida:300 Ataque:75 Defensa:20%");
                    System.out.println("Dragonite Vida:250 Ataque:75 Defensa:20%");
                    System.out.println();
                    System.out.println("Ingrese una pelea determinada");
                    System.out.println("1.- Sylveon vrs Dragonite");
                    System.out.println("2.- Gyarados vrs Giratina");
                    System.out.println("3.- Dragonite vrs Giratina");
                    System.out.println("4.- Giratina vrs Sylveon");
                    System.out.println();
                    int pelea = leer.nextInt();
                    switch (pelea){
                            case 1:{
                              double pokemon1 = 280;
                                double pokemon2 = 250;
                                double vida1, vida2;
                                int ronda =0;
                                while(pokemon1 >0 || pokemon2 >0 ){
                                for(int contador = 1; contador <= 10; contador++){
                                    ronda = contador;
                                System.out.println("-----------Ronda "+ronda+"-----------");
                                    System.out.println();
                                    System.out.println("Pokemon 1 ha atacado");
                                    System.out.println("Pokemon 2 ha atacado");
                                    pokemon1 = pokemon1 - 75;
                                    pokemon2 = pokemon2 - 80;
                                    System.out.println("Vida de pokemon 1: "+pokemon1);
                                    System.out.println("Vida de pokemon 2: "+pokemon2);
                                    
                                
                            }
                            }
                            }
                            break;
                            
                            case 2:{
                                
                            }
                            break;
                            
                            case 3:{
                                
                            }
                            break;
                            
                            case 4:{
                                
                            }
                            break;
                    }//fin switch pelea
                } 
            break;
            
                }//fin switch secundario (modo)
            
}//fin case2 (principal)
            break;
              case 3:{
                System.out.print("Ingrese un número impar y mayor a 7: ");
                int impar = leer.nextInt();
                for (int i=1; i<= impar;i++){
                                 for (int j=1;j<=impar;j++){
                                     if (i==1 || i==impar || j==1 || j==impar){
                                         System.out.print("*");
                                     }
                                     else {
                                         System.out.print(" ");
                                     }
                                     if(j==i){
                                     System.out.print("> ");
                                     }
                                     else {
                                         System.out.print(" ");
                                     }
                                     if (i+j==impar+1){
                                        System.out.print("> ");
                                     }
                                     else{
                                         System.out.print(" ");
                                     }
                                     if (j ==(impar/2)+1){
                                         System.out.print("|");
                                     }
                                     else{
                                         System.out.print(" ");
                                     }
                                 }//for interno
                                 System.out.println();
                                 }
}//fin case 3 (principal)  
            }//fin switch principal
        }
}

